/** Country → ISO-3166 alpha-2 code and settlement currency for each finance hub. */
export const COUNTRY_META: Record<string, { iso2: string; currency: string; currencyName: string }> = {
  "Singapore": { iso2: "SG", currency: "SGD", currencyName: "Singapore Dollar" },
  "UAE": { iso2: "AE", currency: "AED", currencyName: "UAE Dirham" },
  "United Kingdom": { iso2: "GB", currency: "GBP", currencyName: "Pound Sterling" },
  "United States": { iso2: "US", currency: "USD", currencyName: "US Dollar" },
  "India": { iso2: "IN", currency: "USD", currencyName: "US Dollar (IFSC unit currency)" },
  "Hong Kong SAR": { iso2: "HK", currency: "HKD", currencyName: "Hong Kong Dollar" },
  "Switzerland": { iso2: "CH", currency: "CHF", currencyName: "Swiss Franc" },
  "Luxembourg": { iso2: "LU", currency: "EUR", currencyName: "Euro" },
  "Netherlands": { iso2: "NL", currency: "EUR", currencyName: "Euro" },
  "Ireland": { iso2: "IE", currency: "EUR", currencyName: "Euro" },
  "Germany": { iso2: "DE", currency: "EUR", currencyName: "Euro" },
  "France": { iso2: "FR", currency: "EUR", currencyName: "Euro" },
  "Japan": { iso2: "JP", currency: "JPY", currencyName: "Japanese Yen" },
  "China": { iso2: "CN", currency: "CNY", currencyName: "Chinese Yuan" },
  "South Korea": { iso2: "KR", currency: "KRW", currencyName: "Korean Won" },
  "Australia": { iso2: "AU", currency: "AUD", currencyName: "Australian Dollar" },
  "Canada": { iso2: "CA", currency: "CAD", currencyName: "Canadian Dollar" },
  "Israel": { iso2: "IL", currency: "ILS", currencyName: "Israeli Shekel" },
  "Saudi Arabia": { iso2: "SA", currency: "SAR", currencyName: "Saudi Riyal" },
  "Qatar": { iso2: "QA", currency: "QAR", currencyName: "Qatari Riyal" },
  "Bahrain": { iso2: "BH", currency: "BHD", currencyName: "Bahraini Dinar" },
  "Oman": { iso2: "OM", currency: "OMR", currencyName: "Omani Rial" },
  "Kenya": { iso2: "KE", currency: "KES", currencyName: "Kenyan Shilling" },
  "South Africa": { iso2: "ZA", currency: "ZAR", currencyName: "South African Rand" },
  "Nigeria": { iso2: "NG", currency: "NGN", currencyName: "Nigerian Naira" },
  "Egypt": { iso2: "EG", currency: "EGP", currencyName: "Egyptian Pound" },
  "Mauritius": { iso2: "MU", currency: "MUR", currencyName: "Mauritian Rupee" },
  "Brazil": { iso2: "BR", currency: "BRL", currencyName: "Brazilian Real" },
  "Mexico": { iso2: "MX", currency: "MXN", currencyName: "Mexican Peso" },
  "Chile": { iso2: "CL", currency: "CLP", currencyName: "Chilean Peso" },
  "Colombia": { iso2: "CO", currency: "COP", currencyName: "Colombian Peso" },
  "Thailand": { iso2: "TH", currency: "THB", currencyName: "Thai Baht" },
  "Malaysia": { iso2: "MY", currency: "MYR", currencyName: "Malaysian Ringgit" },
  "Indonesia": { iso2: "ID", currency: "IDR", currencyName: "Indonesian Rupiah" },
  "Vietnam": { iso2: "VN", currency: "VND", currencyName: "Vietnamese Dong" },
  "Philippines": { iso2: "PH", currency: "PHP", currencyName: "Philippine Peso" },
  "Sri Lanka": { iso2: "LK", currency: "LKR", currencyName: "Sri Lankan Rupee" },
  "Italy": { iso2: "IT", currency: "EUR", currencyName: "Euro" },
  "Spain": { iso2: "ES", currency: "EUR", currencyName: "Euro" },
  "Sweden": { iso2: "SE", currency: "SEK", currencyName: "Swedish Krona" },
  "Norway": { iso2: "NO", currency: "NOK", currencyName: "Norwegian Krone" },
  "Denmark": { iso2: "DK", currency: "DKK", currencyName: "Danish Krone" },
  "Finland": { iso2: "FI", currency: "EUR", currencyName: "Euro" },
  "Austria": { iso2: "AT", currency: "EUR", currencyName: "Euro" },
  "Belgium": { iso2: "BE", currency: "EUR", currencyName: "Euro" },
  "Poland": { iso2: "PL", currency: "PLN", currencyName: "Polish Zloty" },
  "Portugal": { iso2: "PT", currency: "EUR", currencyName: "Euro" },
};

/** Emoji flag from an ISO-3166 alpha-2 country code. */
export function flag(iso2: string): string {
  return iso2
    .toUpperCase()
    .replace(/./g, (c) => String.fromCodePoint(127397 + c.charCodeAt(0)));
}

/** Indicative INR-base rates used until the live feed answers. */
export const FALLBACK_RATES: Record<string, number> = {
  INR: 1, USD: 0.0115, EUR: 0.0106, GBP: 0.0089, SGD: 0.0153, AED: 0.0422,
  HKD: 0.0895, CHF: 0.0098, JPY: 1.74, CNY: 0.0829, KRW: 15.6, AUD: 0.0177,
  CAD: 0.0159, ILS: 0.0421, SAR: 0.0431, QAR: 0.0418, BHD: 0.0043, OMR: 0.0044,
  KES: 1.49, ZAR: 0.207, NGN: 17.4, EGP: 0.56, MUR: 0.53, BRL: 0.062,
  MXN: 0.213, CLP: 11.1, COP: 46.2, THB: 0.39, MYR: 0.051, IDR: 187,
  VND: 292, PHP: 0.66, LKR: 3.45, SEK: 0.113, NOK: 0.121, DKK: 0.079, PLN: 0.045,
};
