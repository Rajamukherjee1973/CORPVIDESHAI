import { Link, useRouterState } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

const JOURNEY = [
  { to: "/access", label: "Applications", detail: "Corporate · fund · reviewer desks" },
  { to: "/intelligence", label: "Intelligence", detail: "Currencies · hubs · prediction" },
  { to: "/agents", label: "Agent desk", detail: "Graph · copilot · reader · outlook" },
  { to: "/evidence", label: "Working evidence", detail: "Safeguards · simulated case" },
  { to: "/architecture", label: "Architecture", detail: "Boundaries · feasibility · resources" },
  { to: "/decks", label: "Investor materials", detail: "Synopsis · architecture · pitch" },
] as const;

/** Public presentation links only; this strip never grants access or carries private case data. */
export function WorkflowNavigator() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [expanded, setExpanded] = useState(false);
  const current = JOURNEY.findIndex((s) => s.to === path);
  const previous = JOURNEY[current - 1];
  const next = current >= 0 ? JOURNEY[current + 1] : undefined;
  return (
    <section className="border-b border-border bg-secondary/30">
      <div className="mx-auto max-w-[1400px] px-4 sm:px-6">
        <div className="flex min-h-10 items-center justify-between gap-2">
          <Button variant="ghost" size="sm" onClick={() => setExpanded((v) => !v)} aria-expanded={expanded} aria-controls="connected-journey" className="min-w-0 rounded-none px-0 text-xs">
            {expanded ? <ChevronUp /> : <ChevronDown />} Connected desks
            <span className="hidden font-mono-ui text-muted-foreground sm:inline">/ {current >= 0 ? JOURNEY[current]?.label : "Workspace"}</span>
          </Button>
          <div className="flex shrink-0 items-center gap-1">
            {previous && <Button variant="ghost" size="icon" asChild><Link to={previous.to} aria-label={`Previous: ${previous.label}`} title={previous.label}><ArrowLeft /></Link></Button>}
            {next && <Button variant="ghost" size="sm" asChild><Link to={next.to} className="rounded-none">{next.label}<ArrowRight /></Link></Button>}
            {current < 0 && <Button variant="ghost" size="sm" asChild><Link to="/access">Applications<ArrowRight /></Link></Button>}
          </div>
        </div>
        {expanded && <nav id="connected-journey" aria-label="Connected presentation journey" className="grid grid-cols-2 gap-px border-t border-border bg-border pb-px lg:grid-cols-6">
          {JOURNEY.map((step, i) => <Link key={step.to} to={step.to} className={`min-w-0 px-3 py-3 ${path === step.to ? "bg-primary text-primary-foreground" : "bg-background hover:bg-muted"}`}>
            <span className="font-mono-ui text-[10px]">{String(i + 1).padStart(2, "0")}</span>
            <span className="mt-1 block font-display text-base">{step.label}</span>
            <span className="mt-1 block text-[11px] opacity-75">{step.detail}</span>
          </Link>)}
        </nav>}
      </div>
    </section>
  );
}