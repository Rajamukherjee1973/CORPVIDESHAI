import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useId, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { WorkflowNavigator } from "@/components/site/WorkflowNavigator";
import { TreasuryScenarioBar } from "@/components/site/TreasuryScenarioBar";
import { FxTicker } from "@/components/site/FxTicker";
import { FxAutoCapture } from "@/components/site/FxAutoCapture";
import { Button } from "@/components/ui/button";
import { saveSession, sessionLabel, useSession, type Session } from "@/lib/session";

type NavItem = { to: string; label: string; note?: string };
type NavNode = NavItem | { label: string; items: NavItem[] };

const isGroup = (n: NavNode): n is { label: string; items: NavItem[] } => "items" in n;

const PUBLIC_NAV: NavNode[] = [
  { to: "/access", label: "Applications" },
  { label: "Intelligence", items: [
    { to: "/intelligence", label: "Prediction & FX", note: "FX tape · market board · corridor ledger" },
    { to: "/hubs", label: "52 hubs atlas" },
    { to: "/agents", label: "Agent desk · all AI agents" },
    { to: "/frontier", label: "Frontier tools" },
    { to: "/section195", label: "Section 195 & FEMA" },
  ] },
  { label: "Workspaces", items: [
    { to: "/console", label: "Corporate console & filings" },
    { to: "/fund-portal", label: "Fund investor portal" },
    { to: "/gift-portal", label: "GIFT multi-party review" },
    { to: "/regulator-portal", label: "Secure Form FC portal" },
    { to: "/filings", label: "Filings register" },
    { to: "/treasury", label: "Treasury live universe" },
    { to: "/portfolio", label: "OPI portfolio" },
    { to: "/routes", label: "Route intake" },
  ] },
  { label: "Evidence & VC", items: [
    { to: "/evidence", label: "Working evidence studio" },
    { to: "/architecture", label: "Architecture & feasibility" },
    { to: "/investors", label: "Investor brief" },
    { to: "/decks", label: "Presentation downloads" },
    { to: "/proof", label: "Competitive evidence" },
    { to: "/security", label: "Security demonstration" },
  ] },
  { label: "About", items: [
    { to: "/why", label: "Why CorpVidesh AI", note: "Problem · answer · who it serves" },
    { to: "/how-it-works", label: "Architecture & functional diagrams", note: "System · flow · swimlanes · agents · trust" },
    { to: "/compare", label: "Swiss grade vs competitors", note: "Seven stages · head-to-head" },
    { to: "/book-demo", label: "Book a demo", note: "Guided 45-minute walkthrough" },
    { to: "/blog/how-corpvidesh-ai-is-built", label: "Architecture blog", note: "How CorpVidesh AI is built" },
    { to: "/contact", label: "Contact", note: "Email · phone · address · secure message" },
  ] },
];

/** Every remaining surface, listed once in the footer so nothing is orphaned. */
const DIRECTORY_RAW: NavItem[] = [
  { to: "/corporate-dashboard", label: "Corporate dashboard — filings, deadlines and submission" },
  { to: "/console", label: "Treasury console — FEMA and investment intelligence" },
  { to: "/", label: "Rail overview" },
  { to: "/frontier", label: "Frontier desk — AI copilot, stress tests, document reader, early warning" },
  { to: "/filings", label: "Filings register — company outbound transfers and required filings" },
  { to: "/filing-submission", label: "Form FC submissions — simulation records" },
  { to: "/intelligence", label: "Prediction surface — forecast + recommended action, folded desks" },
  {
    to: "/architecture",
    label: "Architecture — retrieval, memory, evaluation, secure tool boundary",
  },
  { to: "/hubs", label: "52 hubs atlas" },
  {
    to: "/intelligence",
    label: "Folded evidence desks — FX tape, 52-hub exchange board, corridor ledger",
  },
  {
    to: "/agents",
    label: "Agent desk — statutory graph, copilot, document reader, currency outlook, connected tools",
  },
  { to: "/evidence", label: "Evidence studio — proof, mechanism, live case simulation" },
  { to: "/gift-portal", label: "GIFT City clearance portal — stored multi-party case ledger" },
  { to: "/fund-portal", label: "Fund investor portal — offshore proposals and GIFT tracking" },
  { to: "/proof", label: "Proof desk — side-by-side vs incumbents" },
  { to: "/routes", label: "Automatic vs Approval routes" },
  { to: "/treasury", label: "Treasury live universe" },
  { to: "/portfolio", label: "OPI portfolio book — allocation, hedge cover, rupee translation P&L" },
  { to: "/apply", label: "Clearance simulator" },
  { to: "/security", label: "Security theatre — live breach demo" },
  { to: "/casefile", label: "Regulator audit timeline + worked money case" },
  { to: "/section195", label: "Section 195 compliance engine — chargeability, TRC/10F, 15CA/15CB" },
  { to: "/supervisor", label: "Supervisor view" },
  { to: "/investors", label: "Investor brief" },
  { to: "/decks", label: "Live decks" },
  { to: "/access", label: "Desk access" },
  { to: "/ssl", label: "HTTPS / SSL status" },
  { to: "/why", label: "Why CorpVidesh AI" },
  { to: "/how-it-works", label: "Architecture & functional diagrams" },
  { to: "/compare", label: "Swiss grade vs competitors" },
  { to: "/book-demo", label: "Book a demo" },
  { to: "/blog", label: "Engineering blog" },
  { to: "/contact", label: "Contact — email, phone, address and secure message form" },
];

const DIRECTORY: NavItem[] = DIRECTORY_RAW.filter((d, i, all) => all.findIndex((x) => x.to === d.to) === i);

export function navFor(_session: Session | null): NavNode[] {
  return PUBLIC_NAV;
}

const NAV_LINK =
  "px-3 py-2 font-mono-ui text-[11px] uppercase tracking-[0.12em] text-muted-foreground transition-colors hover:text-primary [&.active]:text-primary";

function NavDropdown({ label, items }: { label: string; items: NavItem[] }) {
  const [open, setOpen] = useState(false);
  const [shift, setShift] = useState(0);
  const root = useRef<HTMLDivElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const menuId = useId();
  const hoverOpened = useRef(false);
  const path = useRouterState({ select: (s) => s.location.pathname });
  const activeGroup = items.some((i) => i.to === path || (i.to.startsWith("/blog") && path.startsWith("/blog")));
  const later = (v: boolean, ms: number) => { if (timer.current) clearTimeout(timer.current); timer.current = setTimeout(() => setOpen(v), ms); };
  useEffect(() => { setOpen(false); }, [path]);
  useEffect(() => {
    if (!open || !root.current) return;
    const menuWidth = Math.min(320, window.innerWidth * 0.88);
    const left = root.current.getBoundingClientRect().left;
    // Keep the whole menu inside the viewport with an 8px margin on either side.
    setShift(Math.max(8 - left, Math.min(0, window.innerWidth - 8 - menuWidth - left)));
  }, [open]);
  useEffect(() => {
    if (!open) return;
    const away = (e: PointerEvent) => { if (!root.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("pointerdown", away);
    return () => document.removeEventListener("pointerdown", away);
  }, [open]);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  const links = () => Array.from(root.current?.querySelectorAll<HTMLAnchorElement>("[role=menuitem]") ?? []);
  const focusAt = (i: number) => { const l = links(); if (l.length) l[(i + l.length) % l.length]!.focus(); };
  const onKey = (e: KeyboardEvent) => {
    const l = links(); const i = l.indexOf(document.activeElement as HTMLAnchorElement);
    if (e.key === "Escape") { setOpen(false); root.current?.querySelector<HTMLButtonElement>("button")?.focus(); }
    else if (e.key === "ArrowDown") { e.preventDefault(); if (!open) { setOpen(true); requestAnimationFrame(() => focusAt(0)); } else focusAt(i + 1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); if (!open) { setOpen(true); requestAnimationFrame(() => focusAt(-1)); } else focusAt(i - 1); }
    else if (open && e.key === "Home") { e.preventDefault(); focusAt(0); }
    else if (open && e.key === "End") { e.preventDefault(); focusAt(-1); }
  };
  return (
    <div
      ref={root}
      className="relative"
      onPointerEnter={(e) => { if (e.pointerType === "mouse") hoverOpened.current = true; later(true, 80); }}
      onPointerLeave={(e) => { if (e.pointerType === "mouse") hoverOpened.current = false; later(false, 180); }}
      onKeyDown={onKey}
      onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setOpen(false); }}
    >
      <Button
        variant="ghost"
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-controls={menuId}
        onClick={() => { if (timer.current) clearTimeout(timer.current); if (hoverOpened.current) { hoverOpened.current = false; setOpen(true); } else setOpen((v) => !v); }}
        className={`${NAV_LINK} inline-flex items-center gap-1.5 ${open || activeGroup ? "text-primary" : ""}`}
      >
        {label}
        <span aria-hidden className={`text-[8px] leading-none opacity-70 transition-transform ${open ? "rotate-180" : ""}`}>▼</span>
        {activeGroup ? <span aria-hidden className="absolute inset-x-3 bottom-0 h-[2px] bg-primary" /> : null}
      </Button>
      <div
        id={menuId}
        role="menu"
        aria-label={label}
        hidden={!open}
        style={{ left: shift }}
        className="absolute top-full z-50 max-h-[70vh] w-[min(20rem,88vw)] overflow-y-auto border border-rule/20 bg-background shadow-lg"
      >
        <div className="flex items-center justify-between bg-primary px-4 py-1.5 font-mono-ui text-[9px] uppercase tracking-[0.18em] text-primary-foreground">
          <span>{label}</span><span>{items.length} {label === "About" ? "pages" : "desks"}</span>
        </div>
        <ul>
          {items.map((item, i) => {
            const here = item.to === path;
            return (
              <li key={`${item.to}-${item.label}`} className="border-b border-rule/10 last:border-0">
                <Link
                  role="menuitem"
                  to={item.to}
                  aria-current={here ? "page" : undefined}
                  onClick={() => setOpen(false)}
                  className={`group grid grid-cols-[1.75rem_1fr] px-4 py-3 outline-none transition-colors hover:bg-muted/60 focus-visible:bg-muted ${here ? "border-l-2 border-primary bg-muted/40" : "border-l-2 border-transparent"}`}
                >
                  <span className="font-mono-ui text-[10px] text-primary">{String(i + 1).padStart(2, "0")}</span>
                  <span>
                    <span className={`font-mono-ui block text-[11px] uppercase tracking-[0.12em] group-hover:text-primary ${here ? "text-primary" : "text-foreground"}`}>{item.label}</span>
                    {item.note ? <span className="font-mono-ui mt-1 block text-[10px] tracking-[0.06em] text-muted-foreground">{item.note}</span> : null}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

export function Frame({ children }: { children: ReactNode }) {
  const { session } = useSession();
  const nav = navFor(session);
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-50 border-b border-rule/15 bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1400px] flex-col items-start justify-between gap-2 px-4 py-2.5 sm:px-6 lg:flex-row lg:items-center">
          <Link to="/" className="flex items-baseline gap-2.5">
            <span className="block h-3.5 w-3.5 bg-primary" aria-hidden />
            <span className="font-display text-xl tracking-tight">CorpVidesh AI</span>
            <span className="font-mono-ui hidden text-[10px] uppercase tracking-[0.18em] text-muted-foreground sm:block">
              Outbound capital workspace
            </span>
          </Link>
          <nav aria-label="Main navigation" className="flex max-w-full flex-wrap items-center justify-start gap-x-1 lg:justify-end">
            {nav.map((n) =>
              isGroup(n) ? (
                <NavDropdown key={n.label} label={n.label} items={n.items} />
              ) : (
                <Link
                  key={`${n.to}-${n.label}`}
                  to={n.to}
                  preload={n.to === "/access" ? "render" : "intent"}
                  activeOptions={{ exact: n.to === "/" }}
                  className={NAV_LINK}
                >
                  {n.label}
                </Link>
              ),
            )}
            {session ? (
              <span className="ml-2 flex items-center gap-2 border-l border-rule/20 pl-3">
                <span className="font-mono-ui text-[10px] uppercase tracking-[0.12em] text-primary">
                  <span className="block max-w-48 truncate" title={sessionLabel(session)}>{sessionLabel(session)}</span>
                </span>
                <Button variant="outline"
                  onClick={() => saveSession(null)}
                  className="font-mono-ui border border-rule/25 px-2 py-1 text-[9px] uppercase tracking-[0.14em] text-muted-foreground transition-colors hover:text-primary"
                >
                  Clear demo desk
                </Button>
              </span>
            ) : (
              <Link
                to="/access"
                preload="render"
                className="font-mono-ui ml-2 bg-primary px-3 py-2 text-[10px] uppercase tracking-[0.14em] text-primary-foreground"
              >
                Open desks
              </Link>
            )}
          </nav>
        </div>
      </header>
      <FxTicker compact />
      <WorkflowNavigator />
      <TreasuryScenarioBar />
      <main className="pb-16">{children}</main>
      <footer className="mt-8">
        {/* Brand band */}
        <div className="bg-primary text-primary-foreground">
          <div className="mx-auto max-w-[1400px] px-6 py-7">
            <p className="font-mono-ui text-[10px] uppercase tracking-[0.28em] opacity-80">
              CorpVidesh AI · Regulated rail for Indian outbound corporate capital
            </p>
            <p className="mt-4 font-display text-3xl leading-[1.05] md:text-4xl">
              Compliance at the speed
              <br />
              of settlement.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-3 border-t border-primary-foreground/25 pt-6 font-mono-ui text-[11px] uppercase tracking-[0.18em]">
              <span>52 financial hubs</span>
              <span>6 Indian regulators</span>
              <span>Sub-9-minute clearance</span>
              <span>GIFT City · IFSC</span>
            </div>
          </div>
        </div>

        {/* Team + posture grid */}
        <div className="border-t border-rule/15 bg-muted/40">
          <div className="mx-auto grid max-w-[1400px] gap-10 px-6 py-12 md:grid-cols-12">
            <div className="md:col-span-4">
              <p className="font-mono-ui text-[10px] uppercase tracking-[0.22em] text-primary">
                Team Quantum Leap
              </p>
              <p className="mt-2 font-mono-ui text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Department of Law · Brainware University
              </p>
              <ul className="mt-5 space-y-4">
                {[
                  ["Raja Mukherjee", "Team Lead", "BWU/BBL/25/002"],
                  ["Priyanshu Dhar", "Team Co-Lead", "BWU/BBL/24/158"],
                  ["ADITI KULKARNI", "Concept & Corporate Law Support", "BWU/BBL/25/081"],
                ].map(([name, role, code]) => (
                  <li key={name} className="border-l-2 border-primary/70 pl-4">
                    <p className="font-display text-base leading-tight">{name}</p>
                    <p className="mt-0.5 font-mono-ui text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                      {role}
                      {code ? ` · ${code}` : ""}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
            <div className="md:col-span-4">
              <p className="font-mono-ui text-[10px] uppercase tracking-[0.22em] text-primary">
                Posture
              </p>
              <ul className="mt-5 space-y-3">
                {[
                  "Data resident in India",
                  "No custody of client funds",
                  "Append-only evidence ledger",
                  "Prototype — not legal advice",
                ].map((p, i) => (
                  <li key={p} className="flex items-baseline gap-3 text-sm">
                    <span className="font-mono-ui text-[10px] tracking-[0.14em] text-primary">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="md:col-span-4">
              <p className="font-mono-ui text-[10px] uppercase tracking-[0.22em] text-primary">
                All desks
              </p>
              <details className="mt-4"><summary className="cursor-pointer text-sm text-muted-foreground">Complete desk directory</summary><div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2">
                {DIRECTORY.map((d, i) => (
                  <Link
                    key={`${d.to}-${i}`}
                    to={d.to}
                    className="font-mono-ui text-[11px] uppercase tracking-[0.12em] text-muted-foreground transition-colors hover:text-primary"
                  >
                    {d.label}
                  </Link>
                ))}
              </div></details>
            </div>
          </div>
        </div>

        {/* Baseline bar */}
        <div className="border-t border-rule/15 bg-background">
          <div className="mx-auto flex max-w-[1400px] flex-wrap items-center justify-between gap-3 px-6 py-5 font-mono-ui text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            <span>corpvideshai.com — prototype build</span>
            <span>
              Swiss-grade proof of concept · <span className="text-primary">Team Quantum Leap</span>
            </span>
          </div>
        </div>
        <div className="border-t-2 border-primary bg-background">
          <p className="mx-auto max-w-[1400px] px-6 pb-32 pt-4 font-mono-ui sm:pb-20 text-[11px] tracking-[0.08em] text-foreground">
            All Copyrights Protected @ Raja Mukherjee | Department of Law | Brainware University
          </p>
        </div>
      </footer>
      <FxAutoCapture />
    </div>
  );
}

export function Rule({ label }: { label: string }) {
  return (
    <div className="mb-8 flex items-center gap-4 border-t border-rule pt-3">
      <h2 className="font-mono-ui text-[10px] font-normal uppercase tracking-[0.22em] text-primary">
        {label}
      </h2>
    </div>
  );
}